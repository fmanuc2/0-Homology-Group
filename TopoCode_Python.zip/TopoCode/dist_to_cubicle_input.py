#!/usr/bin/python
import sys
import numpy as np

GROUND = 0
NEG_GROUND = None

def transform_values(oriprobs):
    global NEG_GROUND
    ## replace the original values with their orders
    voxel_values = np.argsort(np.argsort(oriprobs))
    neg_voxel_values = np.max(voxel_values) - voxel_values
    voxel_values += 1
    NEG_GROUND = np.max(neg_voxel_values) + 1
    return voxel_values, neg_voxel_values

def serialize(gridcoord, accum):
    return np.dot(gridcoord, accum)

def map_to_grid(oristate, map_each_axis):
    gridcoord = []
    for i in range(len(oristate)):
        gridcoord.append(map_each_axis[i][oristate[i]])
    return gridcoord



if __name__ == '__main__':
    distfn = sys.argv[1]

    original = np.loadtxt(distfn, dtype=float)
    if len(original.shape)!=2:
        original = original.reshape((1,len(original)))
    oriprobs = original[:,-1]
    oristates = original[:,:-1].astype(int)
    m, n = oristates.shape

    ###------- match each state to a point of the 1-interval grid
    map_each_axis = []
    grid_len_each_axis = []
    for i in range(n):
        axismin = np.min(oristates[:,i])
        axismax = np.max(oristates[:,i])
        maptos = range(axismax-axismin+1)
        grid_len_each_axis.append(len(maptos))
        map_each_axis.append(dict(zip(range(axismin, axismax+1),maptos)))

    ###------- transform original values
    voxel_values, neg_voxel_values = transform_values(oriprobs)

    ###------- serialize each state according to the grid
    accum = [1]
    for i in range(len(grid_len_each_axis)-1):
        grid_len_curr_axis = grid_len_each_axis[len(grid_len_each_axis)-i-1]
        accum.append( grid_len_curr_axis *accum[i]  )
    accum = accum[::-1]

    ###------- no all the grid point have values, so we use a dict to store those with values
    serialized_data_dict = {}
    neg_serialized_data_dict = {}
    for i in range(len(oristates)):
        sid = serialize(map_to_grid(oristates[i], map_each_axis), accum)
        serialized_data_dict[sid] = voxel_values[i]
        neg_serialized_data_dict[sid] = neg_voxel_values[i]


    ###------- raw output
    tot_len = 1
    for i in range(len(grid_len_each_axis)):
        tot_len *= grid_len_each_axis[i]

    import struct
    #TODO
    #ofn = distfn[:distfn.rfind('.')] +'.'+ 'x'.join(np.array(grid_len_each_axis).astype(str))+'.raw'
    negofn = distfn[:distfn.rfind('.')] +'.'+ 'x'.join(np.array(grid_len_each_axis).astype(str))+'.negraw'

    #TODO
    #fout =  open(ofn, 'wb')
    negfout = open(negofn, 'wb')
    for i in range(tot_len):
        if i in serialized_data_dict:
            #TODO
            #v = serialized_data_dict[i]
            nv = neg_serialized_data_dict[i]
        else:
            #TODO
            #v = GROUND
            nv = NEG_GROUND
        #TODO
        #fout.write(struct.pack('q', v))
        negfout.write(struct.pack('q', nv))
        #print 'ha' i, nv

    oriprobs = np.expand_dims(oriprobs, axis=1)

    neg_voxel_values = np.expand_dims(neg_voxel_values, axis=1)
    neg_mapping = np.hstack((neg_voxel_values, oriprobs, oristates))
    neg_mapping = np.vstack((neg_mapping, [NEG_GROUND,0]+[-100]*n))
    neg_mapping = neg_mapping[neg_mapping[:,0].argsort()]
    neg_outfn = distfn[:distfn.rfind('.')] +'.negmap'
    np.savetxt(neg_outfn, neg_mapping, fmt='%d\t%.10e\t'+'\t'.join(['%d']*n))
    #with open(neg_outfn,'a') as f:
    #    f.write(str(NEG_GROUND)+'\t0.0000000000e+00\t'+'\t'.join(['NA']*n)+'\n')

    #TODO
    #voxel_values = np.expand_dims(voxel_values, axis=1)
    #mapping = np.hstack((voxel_values, oriprobs, oristates))
    #mapping = np.vstack((mapping, [GROUND,0]+[-100]*n))
    #mapping = mapping[mapping[:,0].argsort()]
    #outfn = distfn[:distfn.rfind('.')] +'.map'
    #np.savetxt(outfn, mapping, fmt='%d\t%.10e\t'+'\t'.join(['%d']*n))



    #fn = distfn[:distfn.rfind('.')] +'.negserialdist'
    #negserialdist = np.hstack((neg_voxel_values, oristates))
    #negserialdist = negserialdist[negserialdist[:,0].argsort()]
    #np.savetxt(fn, negserialdist, fmt='\t'.join(['%d']*(oristates.shape[1]+1)))

